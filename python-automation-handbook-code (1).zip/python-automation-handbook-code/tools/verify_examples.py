"""Run every standalone example script and report PASS/FAIL.

Usage (from the project root):  python tools/verify_examples.py
"""
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EXAMPLES = sorted((ROOT / "examples").glob("ch*.py"))


def main() -> int:
    failures = 0
    for script in EXAMPLES:
        module = f"examples.{script.stem}"
        start = time.perf_counter()
        result = subprocess.run([sys.executable, "-m", module], cwd=ROOT,
                                capture_output=True, text=True, timeout=180)
        took = time.perf_counter() - start
        ok = result.returncode == 0 and "OK" in result.stdout
        failures += not ok
        print(f"{'PASS' if ok else 'FAIL'}  {module:<40} {took:5.1f}s")
        if not ok:
            print(result.stdout[-1500:], result.stderr[-1500:], sep="\n")
    print(f"\n{len(EXAMPLES) - failures}/{len(EXAMPLES)} example scripts passed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())

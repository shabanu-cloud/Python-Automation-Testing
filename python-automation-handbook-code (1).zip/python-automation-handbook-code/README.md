# Python Automation Testing — Companion Code

Runnable, verified source code for **Python Automation Testing: The Practical Professional Handbook (2026 Edition)** by **Sharmila S**.
Everything runs **offline**: a bundled local server provides the demo pages *and* a small JSON API, so no public
endpoints or real accounts are needed.

## Quick start

```bash
# macOS / Linux
./run_tests.sh

# Windows PowerShell
.\run_tests.ps1
```

Or step by step:

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python -m playwright install chromium
python -m pytest -q
python tools/verify_examples.py
```

Supported: Python 3.10 – 3.13, Chrome/Chromium. Expected result: **76 passed** and **7/7 example scripts passed**.

## Try the demo app by hand

```bash
python demo/server.py          # then open http://127.0.0.1:8000/checkout.html
```

## What maps to which chapter

| Chapter | Files |
|---|---|
| 01 Automation mindset | `tests/test_mindset.py` |
| 02 Python foundations | `src/money.py`, `examples/ch02_money.py`, `examples/ch02_python_tour.py`, `tests/test_money.py` |
| 03 Project setup | `requirements.txt`, `pytest.ini`, `.gitignore`, `.env.example`, `run_tests.*` |
| 04 PyTest fundamentals | `tests/test_pytest_basics.py`, `tests/conftest.py` |
| 05 Selenium | `examples/ch05_selenium_script.py`, `pages/selenium_checkout_page.py`, `tests/test_selenium_checkout.py` |
| 06 Playwright | `examples/ch06_playwright_script.py`, `tests/test_playwright_basics.py` |
| 07 Page Object Model | `pages/checkout_page.py`, `examples/ch07_page_object_script.py`, `tests/test_checkout.py` |
| 08 Waits, frames, debugging | `demo/frames.html`, `tests/test_waits_frames.py` |
| 09 Test data & JSON | `test_data/*.json`, `src/data_loader.py`, `tests/test_data_driven.py` |
| 10 API validation | `demo/server.py`, `src/api_client.py`, `examples/ch10_requests_script.py`, `tests/test_api.py` |
| 11 Downloads & PDFs | `src/pdf_tools.py`, `examples/ch11_download_script.py`, `tests/test_download.py` |
| 12 Reports, Git, CI | `.github/workflows/tests.yml`, `--html` report, `artifacts/` |
| 14 Capstone | `demo/checkout.html`, `pages/checkout_page.py`, `tests/test_checkout.py` |
| 15 Exercises | `exercises/` (starters) — worked answers live in the tests listed in `exercises/README.md` |

## Useful commands

```bash
python -m pytest -m unit                 # fast tests only
python -m pytest -m "ui or selenium"     # browser tests
python -m pytest -m api                  # API tests
python -m pytest --headed --slowmo 300   # watch Playwright run
python -m pytest -k checkout -x          # only tests named *checkout*, stop on first failure
python -m playwright show-trace artifacts/<test-folder>/trace.zip   # open a failure trace
```

## Selenium on locked-down machines

Selenium Manager downloads a matching ChromeDriver automatically. If your network blocks that,
download the ChromeDriver that matches your Chrome version and set:

```bash
export CHROMEDRIVER_PATH=/path/to/chromedriver     # PowerShell: $env:CHROMEDRIVER_PATH="C:\path\chromedriver.exe"
```

If Chrome/ChromeDriver can't start, Selenium tests are **skipped with a clear reason** instead of crashing the suite.

## Evidence

- Playwright: screenshots and traces of failing tests are kept in `artifacts/` (see `pytest.ini`).
- Selenium: failing tests save `artifacts/<test-name>.png` (hook in `tests/conftest.py`).
- HTML report: `python -m pytest --html=reports/report.html --self-contained-html`.

## Safety

Educational code is provided as-is. Run it in a test environment. Never use real credentials or customer data
in the bundled demo. Never commit `.env`, tokens, production data or browser profiles.

## License

The companion code is released under the MIT License (see `LICENSE`). The book's text, illustrations and design
are © 2026 Sharmila S, all rights reserved.

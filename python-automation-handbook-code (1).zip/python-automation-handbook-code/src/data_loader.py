"""Load and validate JSON test data so bad fixtures fail early and clearly (Chapter 9)."""
import json
from decimal import Decimal, InvalidOperation
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "test_data"

REQUIRED = {"scenario": str, "quantity": int, "unit_price": str, "expected_total": str}


class DataFileError(ValueError):
    """Raised when a test-data file is missing fields or has wrong types."""


def validate_case(case: dict, source: str = "<memory>") -> dict:
    for field, kind in REQUIRED.items():
        if field not in case:
            raise DataFileError(f"{source}: missing required field '{field}'")
        if not isinstance(case[field], kind) or isinstance(case[field], bool):
            actual = type(case[field]).__name__
            raise DataFileError(
                f"{source}: field '{field}' must be {kind.__name__}, got {actual}")
    for money_field in ("unit_price", "expected_total"):
        try:
            Decimal(case[money_field])
        except InvalidOperation:
            raise DataFileError(f"{source}: '{money_field}' is not a decimal string") from None
    return case


def load_json(name: str):
    path = DATA_DIR / name
    with path.open(encoding="utf-8") as fh:
        return json.load(fh)


def load_case(name: str = "checkout.json") -> dict:
    return validate_case(load_json(name), name)


def load_cases(name: str = "checkout_cases.json") -> list:
    data = load_json(name)
    if not isinstance(data, list) or not data:
        raise DataFileError(f"{name}: expected a non-empty list of cases")
    return [validate_case(c, f"{name}[{i}]") for i, c in enumerate(data)]

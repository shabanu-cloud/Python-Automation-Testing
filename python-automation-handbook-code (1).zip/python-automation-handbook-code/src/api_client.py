"""A thin API client: one place for base URL, timeouts and headers (Chapter 10)."""
import requests


class OrdersApi:
    def __init__(self, base_url: str, timeout: float = 15):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"Accept": "application/json"})

    def health(self):
        return self.session.get(f"{self.base_url}/api/health", timeout=self.timeout)

    def get_order(self, order_id: str):
        return self.session.get(f"{self.base_url}/api/orders/{order_id}", timeout=self.timeout)

    def create_order(self, payload: dict):
        return self.session.post(
            f"{self.base_url}/api/orders", json=payload, timeout=self.timeout)

"""Environment-driven settings. Secrets come from environment variables, never from Git."""
import os

BASE_URL = os.getenv("BASE_URL", "")            # empty = start the local demo server
HEADLESS = os.getenv("HEADLESS", "1") != "0"
CHROME_BINARY = os.getenv("CHROME_BINARY")      # optional: custom Chrome location
CHROMEDRIVER_PATH = os.getenv("CHROMEDRIVER_PATH")  # optional: locked-down VMs
API_TOKEN = os.getenv("API_TOKEN")              # example secret; never hardcode

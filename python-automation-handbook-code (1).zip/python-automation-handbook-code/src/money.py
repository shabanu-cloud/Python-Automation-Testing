"""Currency-safe calculations used throughout the handbook (Chapters 2, 10, 15)."""
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation

CENT = Decimal("0.01")
DEMO_TAX_RATE = Decimal("10")  # illustrative rate used by the capstone demo page


def to_decimal(value) -> Decimal:
    """Convert int/str/float/Decimal to Decimal via str() to avoid float artifacts."""
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"Not a number: {value!r}") from exc


def total_with_tax(subtotal, rate):
    base = Decimal(str(subtotal))
    pct = Decimal(str(rate))
    if base < 0 or pct < 0:
        raise ValueError("Inputs must be nonnegative")
    total = base * (1 + pct / 100)
    return total.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def checkout_totals(quantity, unit_price, rate=DEMO_TAX_RATE) -> dict:
    """Return subtotal, tax and total exactly as the demo checkout page shows them."""
    qty = to_decimal(quantity)
    price = to_decimal(unit_price)
    if qty != qty.to_integral_value() or qty < 1:
        raise ValueError("Quantity must be a whole number of at least 1")
    if price < 0:
        raise ValueError("Unit price must be nonnegative")
    subtotal = (qty * price).quantize(CENT, rounding=ROUND_HALF_UP)
    total = total_with_tax(subtotal, rate)
    tax = (total - subtotal).quantize(CENT, rounding=ROUND_HALF_UP)
    return {"subtotal": subtotal, "tax": tax, "total": total}


def fmt(amount: Decimal) -> str:
    """Format a Decimal with exactly two places, e.g. Decimal('55') -> '55.00'."""
    return str(to_decimal(amount).quantize(CENT, rounding=ROUND_HALF_UP))

"""Text-PDF helpers (Chapter 11). Scanned PDFs need OCR instead of text extraction."""
import re
from decimal import Decimal
from pathlib import Path

from pypdf import PdfReader


def extract_text(path) -> str:
    reader = PdfReader(str(path))
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def normalize(text: str) -> str:
    """Collapse whitespace so assertions don't depend on raw layout positions."""
    return re.sub(r"\s+", " ", text).strip()


def find_invoice_id(text: str):
    match = re.search(r"\bINV-\d+\b", text)
    return match.group(0) if match else None


def find_amount(text: str, label: str):
    match = re.search(rf"{re.escape(label)}\s*:?\s*(\d+\.\d{{2}})", normalize(text))
    return Decimal(match.group(1)) if match else None


def is_pdf(path) -> bool:
    p = Path(path)
    return p.suffix.lower() == ".pdf" and p.read_bytes()[:5] == b"%PDF-"

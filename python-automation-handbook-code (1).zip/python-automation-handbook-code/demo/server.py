"""Local demo server: serves the demo pages AND a small JSON API.

Run it by hand:      python demo/server.py            (http://127.0.0.1:8000)
Tests start it automatically through the `live_server` fixture in tests/conftest.py,
so no internet access and no public echo endpoints are required.
"""
import json
import sys
import threading
from decimal import Decimal, ROUND_HALF_UP
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

DEMO_DIR = Path(__file__).resolve().parent
CENT = Decimal("0.01")
TAX_RATE = Decimal("10")

ORDERS = {
    "1001": {"id": "1001", "customer": "Emma Clarke", "quantity": 2, "unit_price": "25.00"},
    "1002": {"id": "1002", "customer": "Oliver Grant", "quantity": 3, "unit_price": "19.99"},
}


def totals(quantity, unit_price):
    qty = Decimal(str(quantity))
    price = Decimal(str(unit_price))
    if qty != qty.to_integral_value() or qty < 1 or price < 0:
        raise ValueError("quantity must be an integer >= 1 and unit_price >= 0")
    subtotal = (qty * price).quantize(CENT, rounding=ROUND_HALF_UP)
    total = (subtotal * (1 + TAX_RATE / 100)).quantize(CENT, rounding=ROUND_HALF_UP)
    return {"subtotal": str(subtotal), "tax": str(total - subtotal), "total": str(total)}


def make_receipt_pdf(order_id, quantity, unit_price) -> bytes:
    """Build a tiny, valid, text-based PDF without third-party libraries."""
    t = totals(quantity, unit_price)
    lines = [
        "DEMO RECEIPT",
        f"Invoice ID: INV-{order_id}",
        f"Quantity: {quantity}",
        f"Unit price: {Decimal(str(unit_price)).quantize(CENT)}",
        f"Subtotal: {t['subtotal']}",
        f"Tax (10%): {t['tax']}",
        f"Total: {t['total']}",
    ]
    text_ops = ["BT", "/F1 14 Tf", "72 760 Td", "18 TL"]
    for line in lines:
        safe = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        text_ops.append(f"({safe}) Tj T*")
    text_ops.append("ET")
    stream = "\n".join(text_ops).encode("latin-1")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
        b"/Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
    ]
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, obj in enumerate(objects, start=1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + obj + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode()
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    trailer = f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
    out += (trailer + f"startxref\n{xref}\n%%EOF\n").encode()
    return bytes(out)


class DemoHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(DEMO_DIR), **kwargs)

    def log_message(self, fmt, *args):  # keep test output clean
        pass

    def _json(self, status, payload):
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        url = urlparse(self.path)
        parts = [p for p in url.path.split("/") if p]
        if url.path == "/api/health":
            return self._json(200, {"status": "ok", "service": "demo-api"})
        if url.path == "/api/json":  # local stand-in for a public JSON echo endpoint
            slides = [{"title": "Intro"}]
            return self._json(200, {"slideshow": {"title": "Sample", "slides": slides}})
        if len(parts) == 3 and parts[:2] == ["api", "orders"]:
            order = ORDERS.get(parts[2])
            if not order:
                return self._json(404, {"error": "order not found", "id": parts[2]})
            return self._json(200, {**order, **totals(order["quantity"], order["unit_price"])})
        if url.path == "/files/receipt.pdf":
            q = parse_qs(url.query)
            try:
                order_id = q.get("id", ["1001"])[0]
                pdf = make_receipt_pdf(order_id, q.get("qty", ["2"])[0], q.get("price", ["25.00"])[0])
            except Exception:
                return self._json(400, {"error": "invalid receipt parameters"})
            self.send_response(200)
            self.send_header("Content-Type", "application/pdf")
            filename = f"receipt-INV-{q.get('id', ['1001'])[0]}.pdf"
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
            self.send_header("Content-Length", str(len(pdf)))
            self.end_headers()
            self.wfile.write(pdf)
            return
        return super().do_GET()

    def do_POST(self):
        if urlparse(self.path).path != "/api/orders":
            return self._json(404, {"error": "not found"})
        length = int(self.headers.get("Content-Length", 0))
        try:
            data = json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError:
            return self._json(400, {"error": "body must be JSON"})
        missing = [k for k in ("customer", "quantity", "unit_price") if k not in data]
        if missing:
            return self._json(400, {"error": "missing fields", "fields": missing})
        try:
            t = totals(data["quantity"], data["unit_price"])
        except Exception as exc:
            return self._json(422, {"error": str(exc)})
        new_id = str(1000 + len(ORDERS) + 1)
        ORDERS[new_id] = {"id": new_id, "customer": data["customer"],
                          "quantity": data["quantity"], "unit_price": str(data["unit_price"])}
        return self._json(201, {**ORDERS[new_id], **t})


def start_server(port=0):
    """Start in a background thread; port=0 picks a free port. Returns (server, base_url)."""
    server = ThreadingHTTPServer(("127.0.0.1", port), DemoHandler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, f"http://127.0.0.1:{server.server_address[1]}"


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    srv = ThreadingHTTPServer(("127.0.0.1", port), DemoHandler)
    print(f"Demo running at http://127.0.0.1:{port}/checkout.html  (Ctrl+C to stop)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        srv.shutdown()

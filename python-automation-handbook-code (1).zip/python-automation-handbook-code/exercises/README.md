# Exercises

Try each starter file first, then compare with the worked answer.

| # | Exercise | Starter | Worked answer |
|---|---|---|---|
| 1 | Currency-safe total calculator | `ex1_total_calculator.py` | `src/money.py`, `tests/test_money.py` |
| 2 | Parameterize 0, 1 and 5 quantities with IDs | `ex2_parametrize.py` | `tests/test_pytest_basics.py::test_subtotal_by_quantity` |
| 3 | Replace a fixed sleep with a condition | `ex3_no_sleep.py` | `tests/test_waits_frames.py::test_wait_for_condition_not_sleep` |
| 4 | Why a reused session hides defects | `ex4_isolation.md` | `tests/test_isolation.py` |
| 5 | A locator matches two buttons | `ex5_ambiguous_locator.py` | `tests/test_waits_frames.py::test_ambiguous_locator_is_scoped` |

Run a starter with: `python -m pytest exercises/ex2_parametrize.py`
(starters are outside `testpaths`, so they don't affect the main suite).

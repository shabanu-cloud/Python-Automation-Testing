"""Exercise 1 — Write a currency-safe total calculator.

Requirements:
  * accept subtotal and tax percentage as str/int/Decimal
  * return a Decimal with exactly two places, ROUND_HALF_UP
  * raise ValueError for negative inputs
Then run: python -m pytest exercises/ex1_total_calculator.py
"""
from decimal import Decimal

import pytest


def total_with_tax(subtotal, rate):
    raise NotImplementedError("TODO: implement me")


@pytest.mark.parametrize(
    "subtotal, rate, expected",
    [("100", "5", "105.00"), ("0.05", "10", "0.06")],
)
def test_total(subtotal, rate, expected):
    assert total_with_tax(subtotal, rate) == Decimal(expected)


def test_negative():
    with pytest.raises(ValueError):
        total_with_tax("-1", "5")

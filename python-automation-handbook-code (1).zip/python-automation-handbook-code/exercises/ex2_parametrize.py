"""Exercise 2 — Parameterize quantities 0, 1 and 5 with explicit, readable IDs.

TODO: replace the three copy-pasted tests below with ONE parametrized test.
Unit price is 25. Expected subtotals: 0, 25, 125.
"""


def test_zero():
    assert 0 * 25 == 0


def test_one():
    assert 1 * 25 == 25


def test_five():
    assert 5 * 25 == 125

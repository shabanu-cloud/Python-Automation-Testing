# Exercise 4 — Explain why a reused authenticated browser session may hide defects

Write 3–5 sentences before reading the answer.

Hints:
1. Open `demo/checkout.html`, click **Add to wishlist** twice, then open the page in a new tab.
2. What would a test that expects "Saved items: 0" see in that second tab?
3. What happens to that test if it runs first vs. last?

Worked answer: `tests/test_isolation.py` — state leakage, order dependence and false positives.

"""Exercise 3 — Replace a fixed sleep with a condition-based assertion.

This test passes on a fast machine and fails on a slow one. Remove time.sleep
and assert with expect(...).to_have_text(...) instead.
Run: python -m pytest exercises/ex3_no_sleep.py -p no:cacheprovider
(it uses the same live_server/base_url fixtures through the project conftest)
"""
import time

from playwright.sync_api import Page


def test_total_with_sleep(page: Page):
    page.goto("/checkout.html")
    page.get_by_label("Quantity").fill("2")
    page.get_by_label("Unit price").fill("25.00")
    page.get_by_role("button", name="Calculate").click()
    time.sleep(1)                                         # TODO: remove
    assert page.get_by_test_id("total").inner_text() == "55.00"   # TODO: use expect()

"""Exercise 5 — A locator matches two buttons.

The demo page has two "Apply" buttons (Coupon and Gift card). This test fails with a
strict-mode violation. Fix it by scoping to the right section — NOT by adding .first.
"""
from playwright.sync_api import Page, expect


def test_apply_gift_card(page: Page):
    page.goto("/checkout.html")
    page.get_by_role("button", name="Apply").click()          # TODO: scope me
    expect(page.get_by_test_id("gift-status")).to_have_text("Applied")

"""Re-use the main suite fixtures (local demo server) for exercise starters."""
from tests.conftest import base_url, live_server  # noqa: F401

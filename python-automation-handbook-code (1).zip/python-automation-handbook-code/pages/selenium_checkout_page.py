from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


class SeleniumCheckoutPage:
    QTY = (By.CSS_SELECTOR, "[data-testid='qty']")
    PRICE = (By.CSS_SELECTOR, "[data-testid='price']")
    CALCULATE = (By.CSS_SELECTOR, "[data-testid='calculate']")
    TOTAL = (By.CSS_SELECTOR, "[data-testid='total']")
    ERROR = (By.CSS_SELECTOR, "[data-testid='error']")

    def __init__(self, driver, base_url, timeout=10):
        self.driver = driver
        self.base_url = base_url
        self.wait = WebDriverWait(driver, timeout)

    def open(self):
        self.driver.get(f"{self.base_url}/checkout.html")
        self.wait.until(EC.visibility_of_element_located((By.TAG_NAME, "h1")))
        return self

    def calculate(self, qty, price):
        for locator, value in ((self.QTY, qty), (self.PRICE, price)):
            field = self.wait.until(EC.element_to_be_clickable(locator))
            field.clear()
            field.send_keys(value)
        self.wait.until(EC.element_to_be_clickable(self.CALCULATE)).click()

    def total_text(self):
        # Wait for the condition (non-empty total), never a fixed sleep.
        self.wait.until(lambda d: d.find_element(*self.TOTAL).text.strip() != "")
        return self.driver.find_element(*self.TOTAL).text

    def error_text(self):
        return self.wait.until(EC.visibility_of_element_located(self.ERROR)).text

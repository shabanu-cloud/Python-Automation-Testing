from playwright.sync_api import Page, expect


class CheckoutPage:
    def __init__(self, page: Page):
        self.page = page

    def open(self):
        self.page.goto("/checkout.html")
        expect(self.page.get_by_role("heading", name="Checkout demo")).to_be_visible()
        return self

    def calculate(self, qty: str, price: str):
        self.page.get_by_label("Quantity").fill(qty)
        self.page.get_by_label("Unit price").fill(price)
        self.page.get_by_role("button", name="Calculate").click()

    def expect_total(self, amount: str):
        expect(self.page.get_by_test_id("total")).to_have_text(amount)

    def expect_receipt(self, subtotal: str, tax: str, total: str):
        expect(self.page.get_by_test_id("subtotal")).to_have_text(subtotal)
        expect(self.page.get_by_test_id("tax")).to_have_text(tax)
        self.expect_total(total)

    def expect_error(self, message_part: str):
        expect(self.page.get_by_role("alert")).to_contain_text(message_part)
        expect(self.page.get_by_test_id("receipt")).to_be_hidden()

    def export_pdf(self):
        """Return the Playwright Download object for the receipt PDF."""
        with self.page.expect_download() as download_info:
            self.page.get_by_role("button", name="Export PDF").click()
        return download_info.value

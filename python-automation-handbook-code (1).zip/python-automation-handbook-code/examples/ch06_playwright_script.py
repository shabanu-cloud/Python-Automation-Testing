"""Chapter 6 Playwright sync-API example. Run: python -m examples.ch06_playwright_script"""
from playwright.sync_api import sync_playwright, expect

from demo.server import start_server

server, base_url = start_server()

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto(f"{base_url}/checkout.html")
    expect(page.get_by_role("heading", level=1)).to_be_visible()
    print("Heading:", page.get_by_role("heading", level=1).inner_text())
    browser.close()

server.shutdown()
print("OK")

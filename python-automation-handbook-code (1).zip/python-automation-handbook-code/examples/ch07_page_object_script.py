"""Chapter 7: the CheckoutPage page object used from a plain script.
Run: python -m examples.ch07_page_object_script
"""
from playwright.sync_api import sync_playwright

from demo.server import start_server
from pages.checkout_page import CheckoutPage

server, base_url = start_server()

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    context = browser.new_context(base_url=base_url)   # enables page.goto("/checkout.html")
    page = context.new_page()
    checkout = CheckoutPage(page).open()
    checkout.calculate("2", "25.00")
    checkout.expect_total("55.00")
    print("Total verified: 55.00")
    browser.close()

server.shutdown()
print("OK")

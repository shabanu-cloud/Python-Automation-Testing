"""Chapter 10 requests example. Run: python -m examples.ch10_requests_script

The book's version calls https://httpbin.org/json (needs internet).
This one calls the identical-shaped local endpoint /api/json.
"""
import requests

from demo.server import start_server


def test_api_status(base_url):
    response = requests.get(f"{base_url}/api/json", timeout=15)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)


if __name__ == "__main__":
    server, url = start_server()
    try:
        test_api_status(url)
        print("GET /api/json -> 200, JSON object")
        print("OK")
    finally:
        server.shutdown()

"""Chapter 5 Selenium example. Run: python -m examples.ch05_selenium_script

Uses the local demo server instead of https://example.com so it works offline.
Optional env vars for locked-down machines: CHROMEDRIVER_PATH, CHROME_BINARY.
"""
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from demo.server import start_server
from src import config

server, base_url = start_server()

options = webdriver.ChromeOptions()
options.add_argument("--headless=new")
options.add_argument("--no-sandbox")
if config.CHROME_BINARY:
    options.binary_location = config.CHROME_BINARY
service = Service(config.CHROMEDRIVER_PATH) if config.CHROMEDRIVER_PATH else Service()

driver = webdriver.Chrome(service=service, options=options)
try:
    driver.get(f"{base_url}/checkout.html")
    heading = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.TAG_NAME, "h1")))
    assert heading.text
    print("Heading:", heading.text)
    print("OK")
finally:
    driver.quit()
    server.shutdown()

"""Chapter 11 download example. Run: python -m examples.ch11_download_script
Saves the receipt into ./artifacts and prints the extracted total.
"""
from pathlib import Path

from playwright.sync_api import sync_playwright

from demo.server import start_server
from pages.checkout_page import CheckoutPage
from src.pdf_tools import extract_text, find_amount, find_invoice_id

server, base_url = start_server()

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_context(base_url=base_url, accept_downloads=True).new_page()
    checkout = CheckoutPage(page).open()
    checkout.calculate("2", "25.00")
    checkout.expect_total("55.00")

    with page.expect_download() as download_info:
        page.get_by_role("button", name="Export PDF").click()
    download = download_info.value
    target = Path("artifacts") / download.suggested_filename
    target.parent.mkdir(exist_ok=True)
    download.save_as(target)
    assert target.exists() and target.stat().st_size > 0

    text = extract_text(target)
    print("Saved:", target)
    print("Invoice:", find_invoice_id(text), "| Total:", find_amount(text, "Total"))
    browser.close()

server.shutdown()
print("OK")

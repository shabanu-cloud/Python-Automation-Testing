"""Chapter 2: the Python a tester uses every day. Run: python -m examples.ch02_python_tour"""
import json
import logging
import tempfile
from decimal import Decimal
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
log = logging.getLogger("tour")

# Strings and f-strings
customer = "Emma Clarke"
invoice_id = 1001
label = f"INV-{invoice_id} for {customer.upper()}"
assert label == "INV-1001 for EMMA CLARKE"

# Lists: ordered, can repeat
quantities = [1, 2, 5]
assert quantities[0] == 1 and quantities[-1] == 5 and len(quantities) == 3

# Dictionaries: key -> value (perfect for test data)
order = {"customer": customer, "quantity": 2, "unit_price": "25.00"}
order["status"] = "new"
assert order.get("discount", "0") == "0"          # safe lookup with a default

# Comprehensions: build test data compactly
subtotals = [q * Decimal("25.00") for q in quantities]
assert subtotals == [Decimal("25.00"), Decimal("50.00"), Decimal("125.00")]
big_orders = {q: s for q, s in zip(quantities, subtotals) if s > 30}
assert big_orders == {2: Decimal("50.00"), 5: Decimal("125.00")}

# Control flow
def classify(total: Decimal) -> str:
    if total >= 100:
        return "large"
    elif total > 0:
        return "standard"
    return "empty"

assert [classify(s) for s in subtotals] == ["standard", "standard", "large"]

# Exceptions: raise specific errors, catch only what you can handle
class OrderError(ValueError):
    """A domain-specific error is easier to assert on than a bare Exception."""

def parse_quantity(text: str) -> int:
    try:
        value = int(text)
    except ValueError:
        raise OrderError(f"Quantity must be a whole number, got {text!r}") from None
    if value < 1:
        raise OrderError("Quantity must be at least 1")
    return value

assert parse_quantity("3") == 3
for bad in ["0", "abc"]:
    try:
        parse_quantity(bad)
    except OrderError as exc:
        log.info("rejected %r: %s", bad, exc)
    else:
        raise AssertionError("expected OrderError")

# Files with pathlib + context managers ("with" closes the file for you)
with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / "order.json"
    path.write_text(json.dumps(order, indent=2), encoding="utf-8")
    loaded = json.loads(path.read_text(encoding="utf-8"))
    assert loaded == order

print("OK")

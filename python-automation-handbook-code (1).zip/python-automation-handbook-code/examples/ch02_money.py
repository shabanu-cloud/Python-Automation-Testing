"""Chapter 2 example, exactly as printed in the book. Run: python -m examples.ch02_money"""
from decimal import Decimal, ROUND_HALF_UP


def total_with_tax(subtotal, rate):
    base = Decimal(str(subtotal))
    pct = Decimal(str(rate))
    if base < 0 or pct < 0:
        raise ValueError("Inputs must be nonnegative")
    total = base * (1 + pct / 100)
    return total.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


assert total_with_tax("100", "5") == Decimal("105.00")

if __name__ == "__main__":
    print("total_with_tax('100', '5') =", total_with_tax("100", "5"))
    print("OK")

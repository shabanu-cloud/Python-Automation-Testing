"""Chapters 7 and 14 (capstone): Page Object Model, negative and parameterized tests."""
import pytest
from playwright.sync_api import Page

from pages.checkout_page import CheckoutPage
from src.data_loader import load_case, load_cases
from src.money import checkout_totals, fmt

pytestmark = pytest.mark.ui


@pytest.fixture
def checkout(page: Page) -> CheckoutPage:
    return CheckoutPage(page).open()


def test_demo_total(checkout):
    """Acceptance criterion: quantity 2 x 25.00 -> total 55.00."""
    checkout.calculate("2", "25.00")
    checkout.expect_total("55.00")


def test_full_receipt(checkout):
    checkout.calculate("2", "25.00")
    checkout.expect_receipt(subtotal="50.00", tax="5.00", total="55.00")


@pytest.mark.parametrize(
    "qty, price, message",
    [
        ("0", "25.00", "at least 1"),
        ("-2", "25.00", "at least 1"),
        ("1.5", "25.00", "whole number"),
        ("abc", "25.00", "whole number"),
        ("", "25.00", "whole number"),
        ("2", "abc", "Unit price"),
    ],
    ids=["zero", "negative", "fraction", "text", "empty", "bad-price"],
)
def test_invalid_input_is_rejected(checkout, qty, price, message):
    checkout.calculate(qty, price)
    checkout.expect_error(message)


@pytest.mark.parametrize("case", load_cases(), ids=lambda c: c["scenario"])
def test_valid_inputs_from_json(checkout, case):
    checkout.calculate(str(case["quantity"]), case["unit_price"])
    checkout.expect_total(case["expected_total"])


def test_ui_matches_python_oracle(checkout):
    """The page and an independent Python calculation must agree."""
    expected = checkout_totals(7, "13.33")
    checkout.calculate("7", "13.33")
    checkout.expect_receipt(
        fmt(expected["subtotal"]), fmt(expected["tax"]), fmt(expected["total"]))


def test_single_json_case(checkout):
    case = load_case("checkout.json")
    checkout.calculate(str(case["quantity"]), case["unit_price"])
    checkout.expect_total(case["expected_total"])

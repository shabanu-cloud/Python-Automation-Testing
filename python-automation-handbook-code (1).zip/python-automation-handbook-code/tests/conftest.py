"""Shared fixtures for the whole suite.

- live_server / base_url : starts the local demo app + API on a free port (no internet needed)
- driver                 : a Selenium Chrome driver, created fresh for every test
- Selenium screenshots on failure go to artifacts/
- Playwright evidence (screenshots, traces) is configured in pytest.ini
"""
from pathlib import Path

import pytest

from demo.server import start_server
from src import config

ARTIFACTS = Path(__file__).resolve().parent.parent / "artifacts"


@pytest.fixture(scope="session")
def live_server():
    if config.BASE_URL:              # point the suite at another environment if you must
        yield config.BASE_URL.rstrip("/")
        return
    server, url = start_server()
    yield url
    server.shutdown()


@pytest.fixture(scope="session")
def base_url(live_server):
    """Overrides pytest-playwright's base_url so page.goto('/checkout.html') works."""
    return live_server


@pytest.fixture
def driver():
    selenium = pytest.importorskip("selenium")
    from selenium import webdriver
    from selenium.common.exceptions import WebDriverException
    from selenium.webdriver.chrome.service import Service

    options = webdriver.ChromeOptions()
    if config.HEADLESS:
        options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--window-size=1280,900")
    if config.CHROME_BINARY:
        options.binary_location = config.CHROME_BINARY
    service = Service(config.CHROMEDRIVER_PATH) if config.CHROMEDRIVER_PATH else Service()
    try:
        drv = webdriver.Chrome(service=service, options=options)
    except WebDriverException as exc:
        pytest.skip(f"Chrome/ChromeDriver not available ({exc.msg.splitlines()[0]}). "
                    "Set CHROMEDRIVER_PATH / CHROME_BINARY, see README.")
    yield drv
    drv.quit()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """Save a Selenium screenshot when a test using the `driver` fixture fails."""
    outcome = yield
    report = outcome.get_result()
    if report.when == "call" and report.failed and "driver" in item.fixturenames:
        drv = item.funcargs.get("driver")
        if drv is not None:
            ARTIFACTS.mkdir(exist_ok=True)
            drv.save_screenshot(str(ARTIFACTS / f"{item.name}.png"))

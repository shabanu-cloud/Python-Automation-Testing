"""Chapter 11: capture a download, save it to a controlled path, verify its contents."""
import uuid
from decimal import Decimal
from pathlib import Path

import pytest
from playwright.sync_api import Page

from pages.checkout_page import CheckoutPage
from src.pdf_tools import extract_text, find_amount, find_invoice_id, is_pdf

pytestmark = pytest.mark.ui


def test_export_pdf(page: Page, tmp_path: Path):
    checkout = CheckoutPage(page).open()
    checkout.calculate("2", "25.00")
    checkout.expect_total("55.00")

    with page.expect_download() as download_info:
        page.get_by_role("button", name="Export PDF").click()
    download = download_info.value

    # Unique folder per run: never overwrite previous evidence.
    target = tmp_path / f"run-{uuid.uuid4().hex[:8]}" / download.suggested_filename
    target.parent.mkdir(parents=True, exist_ok=True)
    download.save_as(target)

    assert target.exists() and target.stat().st_size > 0
    assert download.suggested_filename == "receipt-INV-1001.pdf"
    assert is_pdf(target)

    text = extract_text(target)
    assert find_invoice_id(text) == "INV-1001"
    assert find_amount(text, "Subtotal") == Decimal("50.00")
    assert find_amount(text, "Total") == Decimal("55.00")


def test_page_object_download(page: Page, tmp_path: Path):
    checkout = CheckoutPage(page).open()
    checkout.calculate("3", "19.99")
    checkout.expect_total("65.97")
    download = checkout.export_pdf()
    target = tmp_path / download.suggested_filename
    download.save_as(target)
    assert find_amount(extract_text(target), "Total") == Decimal("65.97")

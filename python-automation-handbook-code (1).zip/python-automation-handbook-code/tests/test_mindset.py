"""Chapter 1: the anatomy of a good test - Arrange, Act, Assert, Cleanup."""
import pytest
from playwright.sync_api import Browser, expect

from src.api_client import OrdersApi

pytestmark = pytest.mark.ui


def test_order_total_shown_in_checkout(browser: Browser, base_url, live_server):
    # Arrange: a known state - a fresh, isolated browser context and a known order.
    order = OrdersApi(live_server).get_order("1001").json()
    context = browser.new_context(base_url=base_url)
    page = context.new_page()
    page.goto("/checkout.html")

    # Act: one meaningful business action.
    page.get_by_label("Quantity").fill(str(order["quantity"]))
    page.get_by_label("Unit price").fill(order["unit_price"])
    page.get_by_role("button", name="Calculate").click()

    # Assert: a user-visible outcome that matters to the business.
    expect(page.get_by_test_id("total")).to_have_text(order["total"])

    # Cleanup: remove what the test created.
    context.close()

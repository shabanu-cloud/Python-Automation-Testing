"""Chapter 4 + Exercise 2: discovery, fixtures, scope, parameterization with IDs."""
import pytest

from src.money import checkout_totals, fmt

pytestmark = pytest.mark.unit


# --- The book's example, unchanged -------------------------------------------
@pytest.fixture
def user():
    return {"role": "tester", "active": True}


@pytest.mark.parametrize("qty, expected", [(1, 25), (2, 50)])
def test_subtotal(qty, expected, user):
    assert user["active"]
    assert qty * 25 == expected


# --- Exercise 2: parameterize 0, 1 and 5 with explicit IDs ------------------
@pytest.mark.parametrize(
    "qty, expected_subtotal",
    [
        pytest.param(0, 0, id="zero-items"),
        pytest.param(1, 25, id="one-item"),
        pytest.param(5, 125, id="five-items"),
    ],
)
def test_subtotal_by_quantity(qty, expected_subtotal):
    assert qty * 25 == expected_subtotal


# --- Setup + teardown with yield -----------------------------------------------
@pytest.fixture
def temp_report(tmp_path):
    report = tmp_path / "report.txt"
    report.write_text("started\n")
    yield report                      # the test runs here
    report.unlink()                   # teardown runs even if the test fails


def test_fixture_teardown(temp_report):
    temp_report.write_text(temp_report.read_text() + "finished\n")
    assert temp_report.read_text().splitlines() == ["started", "finished"]


# --- Scope demonstration -------------------------------------------------------
CALLS = {"function": 0, "module": 0}


@pytest.fixture
def per_test():
    CALLS["function"] += 1
    return CALLS["function"]


@pytest.fixture(scope="module")
def per_module():
    CALLS["module"] += 1
    return CALLS["module"]


@pytest.mark.parametrize("_", range(3))
def test_scopes(_, per_test, per_module):
    assert per_module == 1            # created once for the whole module
    assert per_test == CALLS["function"]  # created fresh for every test


# --- Expected exceptions are assertions too ------------------------------------
def test_invalid_quantity_message():
    with pytest.raises(ValueError, match="at least 1"):
        checkout_totals(0, "25.00")


def test_formatting():
    assert fmt(checkout_totals(1, "25")["total"]) == "27.50"

"""Chapter 10: API checks - status, schema, required keys, content and error behavior."""
from decimal import Decimal

import pytest
import requests

from src.api_client import OrdersApi
from src.money import checkout_totals

pytestmark = pytest.mark.api


@pytest.fixture
def api(live_server):
    return OrdersApi(live_server)


def test_api_status(live_server):
    """The book's example, pointed at the local stand-in for httpbin.org/json."""
    response = requests.get(f"{live_server}/api/json", timeout=15)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)


def test_health(api):
    r = api.health()
    assert r.status_code == 200
    assert r.headers["Content-Type"].startswith("application/json")
    assert r.json()["status"] == "ok"


def test_order_schema_and_content(api):
    r = api.get_order("1001")
    assert r.status_code == 200
    body = r.json()
    required = {"id": str, "customer": str, "quantity": int, "unit_price": str,
                "subtotal": str, "tax": str, "total": str}
    for key, kind in required.items():
        assert key in body, f"missing key {key}"
        assert isinstance(body[key], kind), f"{key} should be {kind.__name__}"
    oracle = checkout_totals(body["quantity"], body["unit_price"])
    assert Decimal(body["total"]) == oracle["total"]


def test_unknown_order_returns_404(api):
    r = api.get_order("9999")
    assert r.status_code == 404
    assert r.json()["error"] == "order not found"


def test_create_order(api):
    r = api.create_order({"customer": "Liam Turner", "quantity": 3, "unit_price": "19.99"})
    assert r.status_code == 201
    body = r.json()
    assert body["total"] == "65.97"
    assert api.get_order(body["id"]).json()["customer"] == "Liam Turner"   # persisted


@pytest.mark.parametrize(
    "payload, status",
    [
        ({"quantity": 1, "unit_price": "5.00"}, 400),                         # missing customer
        ({"customer": "Ava Hill", "quantity": 0, "unit_price": "5.00"}, 422),  # rule violation
        ({"customer": "Ava Hill", "quantity": 1, "unit_price": "-1"}, 422),
    ],
    ids=["missing-field", "zero-qty", "negative-price"],
)
def test_create_order_errors(api, payload, status):
    r = api.create_order(payload)
    assert r.status_code == status
    assert "error" in r.json()

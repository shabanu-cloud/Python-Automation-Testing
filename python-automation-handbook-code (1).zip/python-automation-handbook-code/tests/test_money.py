"""Chapter 2 + Exercise 1: currency-safe arithmetic with Decimal."""
from decimal import Decimal

import pytest

from src.money import checkout_totals, fmt, total_with_tax

pytestmark = pytest.mark.unit


def test_book_example():
    assert total_with_tax("100", "5") == Decimal("105.00")


@pytest.mark.parametrize(
    "subtotal, rate, expected",
    [
        ("100", "5", "105.00"),
        ("19.99", "10", "21.99"),     # 21.989 -> 21.99 (half up)
        ("0.05", "10", "0.06"),       # 0.055 -> 0.06, float would give 0.05
        ("0", "18", "0.00"),
        (50, 10, "55.00"),            # ints are accepted too
    ],
    ids=["book-example", "rounds-up", "half-up-edge", "zero-subtotal", "int-inputs"],
)
def test_total_with_tax(subtotal, rate, expected):
    assert total_with_tax(subtotal, rate) == Decimal(expected)


@pytest.mark.parametrize(
    "subtotal, rate", [("-1", "5"), ("10", "-5")], ids=["neg-subtotal", "neg-rate"])
def test_negative_inputs_raise(subtotal, rate):
    with pytest.raises(ValueError, match="nonnegative"):
        total_with_tax(subtotal, rate)


def test_float_trap_is_real():
    assert 0.1 + 0.2 != 0.3                                   # binary floating point
    assert Decimal("0.1") + Decimal("0.2") == Decimal("0.3")  # exact decimal


def test_checkout_totals_matches_demo_page():
    assert checkout_totals(2, "25.00") == {
        "subtotal": Decimal("50.00"), "tax": Decimal("5.00"), "total": Decimal("55.00")}


@pytest.mark.parametrize(
    "qty", [0, -1, "1.5", "abc"], ids=["zero", "negative", "fraction", "text"])
def test_checkout_rejects_invalid_quantity(qty):
    with pytest.raises(ValueError):
        checkout_totals(qty, "25.00")


def test_fmt_always_two_places():
    assert fmt(Decimal("55")) == "55.00"

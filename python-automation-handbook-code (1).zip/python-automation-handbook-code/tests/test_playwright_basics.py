"""Chapter 6: Playwright locators and retrying assertions (pytest-playwright plugin).

The standalone sync_playwright() script lives in examples/ch06_playwright_script.py:
do not mix the plugin and a hand-made sync_playwright() in the same pytest run.
"""
import re

import pytest
from playwright.sync_api import Page, expect

pytestmark = pytest.mark.ui


def test_role_label_testid_locators(page: Page):
    """pytest-playwright gives each test a fresh `page` (new context = isolation)."""
    page.goto("/checkout.html")
    page.get_by_label("Quantity").fill("2")
    page.get_by_label("Unit price").fill("25.00")
    page.get_by_role("button", name="Calculate").click()
    # Retrying assertion: waits for the 300 ms simulated round-trip automatically.
    expect(page.get_by_test_id("total")).to_have_text("55.00")


def test_title_and_url(page: Page):
    page.goto("/checkout.html")
    expect(page).to_have_title("Checkout Demo")
    expect(page).to_have_url(re.compile(r"/checkout\.html$"))

"""Exercise 4: why a reused session can hide defects - contexts give clean state."""
import pytest
from playwright.sync_api import Browser, expect

pytestmark = pytest.mark.ui


def add_to_wishlist(page, base_url, times):
    page.goto(f"{base_url}/checkout.html")
    for _ in range(times):
        page.get_by_role("button", name="Add to wishlist").click()


def test_shared_context_leaks_state(browser: Browser, base_url):
    context = browser.new_context()
    first, second = context.new_page(), context.new_page()
    add_to_wishlist(first, base_url, 2)
    second.goto(f"{base_url}/checkout.html")
    # Same context -> same localStorage: the second "test" sees leftovers.
    expect(second.get_by_test_id("wishlist-count")).to_have_text("2")
    context.close()


def test_new_context_is_clean(browser: Browser, base_url):
    dirty = browser.new_context()
    add_to_wishlist(dirty.new_page(), base_url, 2)
    clean = browser.new_context()
    page = clean.new_page()
    page.goto(f"{base_url}/checkout.html")
    expect(page.get_by_test_id("wishlist-count")).to_have_text("0")
    dirty.close()
    clean.close()

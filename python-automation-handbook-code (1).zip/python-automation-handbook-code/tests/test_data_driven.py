"""Chapter 9: externalized JSON data, early validation, readable IDs."""
import pytest

from src.data_loader import DataFileError, load_case, load_cases, validate_case
from src.money import checkout_totals, fmt

pytestmark = pytest.mark.unit


def test_book_json_is_valid():
    case = load_case("checkout.json")
    assert case["scenario"] == "demo_checkout"


@pytest.mark.parametrize("case", load_cases(), ids=lambda c: c["scenario"])
def test_expected_totals_are_correct(case):
    """Guards the guard: the data file itself is checked against the Python oracle."""
    oracle = checkout_totals(case["quantity"], case["unit_price"])
    assert fmt(oracle["total"]) == case["expected_total"]


@pytest.mark.parametrize(
    "bad_case, message",
    [
        ({"quantity": 2, "unit_price": "25.00", "expected_total": "55.00"},
         "missing required field 'scenario'"),
        ({"scenario": "x", "quantity": "2", "unit_price": "25.00", "expected_total": "55.00"},
         "'quantity' must be int"),
        ({"scenario": "x", "quantity": 2, "unit_price": "abc", "expected_total": "55.00"},
         "not a decimal"),
        ({"scenario": "x", "quantity": True, "unit_price": "1", "expected_total": "1"},
         "'quantity' must be int"),
    ],
    ids=["missing-field", "wrong-type", "bad-money", "bool-is-not-int"],
)
def test_invalid_data_fails_clearly(bad_case, message):
    with pytest.raises(DataFileError, match=message):
        validate_case(bad_case, "inline")


def test_unique_values_per_run(tmp_path):
    """Repeated-run uniqueness: generate names instead of hardcoding them."""
    import uuid
    names = {f"order-{uuid.uuid4().hex[:8]}" for _ in range(100)}
    assert len(names) == 100

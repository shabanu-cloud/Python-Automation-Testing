"""Chapter 8 + Exercises 3 and 5: condition-based waits, iframes, popups, scoped locators."""
import pytest
from playwright.sync_api import Page, expect

pytestmark = pytest.mark.ui


def test_wait_for_condition_not_sleep(page: Page):
    """Exercise 3: no wait_for_timeout - the assertion retries until the text appears."""
    page.goto("/checkout.html")
    page.get_by_label("Quantity").fill("2")
    page.get_by_label("Unit price").fill("25.00")
    page.get_by_role("button", name="Calculate").click()
    expect(page.get_by_test_id("total")).to_have_text("55.00")


def test_delayed_list_items(page: Page):
    """Items arrive after ~1.5 s; to_have_count waits up to the default 5 s timeout."""
    page.goto("/checkout.html")
    page.get_by_role("button", name="Load recommendations").click()
    expect(page.get_by_test_id("recommendations").get_by_role("listitem")).to_have_count(3)


def test_iframe_form(page: Page):
    page.goto("/frames.html")
    frame = page.frame_locator("#support-frame")
    frame.get_by_label("Email").fill("emma@example.com")
    frame.get_by_label("Message").fill("Total looks wrong")
    frame.get_by_role("button", name="Send").click()
    expect(frame.get_by_role("status")).to_have_text("Thanks, we received your message.")


def test_popup_tab(page: Page):
    page.goto("/frames.html")
    with page.expect_popup() as popup_info:
        page.get_by_role("link", name="Open help in new tab").click()
    help_page = popup_info.value
    help_page.wait_for_load_state()
    expect(help_page.get_by_role("heading", level=1)).to_have_text("Help articles")


def test_ambiguous_locator_is_scoped(page: Page):
    """Exercise 5: two 'Apply' buttons exist. Scope to a stable parent instead of .first."""
    page.goto("/checkout.html")
    apply_buttons = page.get_by_role("button", name="Apply")
    expect(apply_buttons).to_have_count(2)          # proves the ambiguity is real

    gift_card = page.get_by_role("region", name="Gift card")
    gift_card.get_by_role("button", name="Apply").click()
    expect(page.get_by_test_id("gift-status")).to_have_text("Applied")
    expect(page.get_by_test_id("coupon-status")).to_have_text("")


def test_console_messages_are_captured(page: Page):
    """Debugging aid: collect browser console output as evidence."""
    messages = []
    page.on("console", lambda msg: messages.append(msg.text))
    page.goto("/checkout.html")
    page.get_by_label("Quantity").fill("2")
    page.get_by_label("Unit price").fill("25.00")
    page.get_by_role("button", name="Calculate").click()
    expect(page.get_by_test_id("total")).to_have_text("55.00")
    assert "calculated total 55.00" in messages

"""Chapter 5: Selenium WebDriver with explicit waits and stable data-testid selectors."""
import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from pages.selenium_checkout_page import SeleniumCheckoutPage

pytestmark = pytest.mark.selenium


def test_heading_visible(driver, base_url):
    """The book's Selenium example, pointed at the local demo instead of example.com."""
    driver.get(f"{base_url}/checkout.html")
    heading = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.TAG_NAME, "h1")))
    assert heading.text


def test_total_with_page_object(driver, base_url):
    page = SeleniumCheckoutPage(driver, base_url).open()
    page.calculate("2", "25.00")
    assert page.total_text() == "55.00"


def test_invalid_quantity_shows_error(driver, base_url):
    page = SeleniumCheckoutPage(driver, base_url).open()
    page.calculate("0", "25.00")
    assert "at least 1" in page.error_text()

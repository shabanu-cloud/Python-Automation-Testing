# One-command setup + verification for Windows PowerShell.
# If scripts are blocked: Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Test-Path ".venv")) { python -m venv .venv }
. .\.venv\Scripts\Activate.ps1
python -m pip install -q -r requirements.txt
python -m playwright install chromium

python -m pytest --html=reports/report.html --self-contained-html
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python tools/verify_examples.py
Write-Host "All checks finished. HTML report: reports/report.html"

#!/usr/bin/env bash
# One-command setup + verification for macOS/Linux.
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
python -m pip install -q -r requirements.txt
python -m playwright install chromium

python -m pytest --html=reports/report.html --self-contained-html
python tools/verify_examples.py
echo "All checks finished. HTML report: reports/report.html"

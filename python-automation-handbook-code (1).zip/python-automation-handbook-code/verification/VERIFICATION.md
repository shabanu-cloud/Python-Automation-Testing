# Verification report

Generated automatically on 27 October 2026, 14:14 while building
*Python Automation Testing: The Practical Professional Handbook*.

**Result: 76 passed in 22.40s · 7/7 example scripts passed**

## Test suite by module

| Module | What it verifies | Passed | Failed |
|---|---|---|---|
| `tests/test_api.py` | API status, schema, content, errors, persistence | 8 | 0 |
| `tests/test_checkout.py` | Capstone: POM, negative, JSON-driven, oracle | 15 | 0 |
| `tests/test_data_driven.py` | Data validation and oracle check of JSON | 11 | 0 |
| `tests/test_download.py` | Download, file type, PDF text and amounts | 2 | 0 |
| `tests/test_isolation.py` | Shared vs new browser contexts | 2 | 0 |
| `tests/test_mindset.py` | Arrange · Act · Assert · Cleanup | 1 | 0 |
| `tests/test_money.py` | Decimal maths, rounding, invalid input | 15 | 0 |
| `tests/test_playwright_basics.py` | Locators, retrying assertions | 2 | 0 |
| `tests/test_pytest_basics.py` | Fixtures, scope, yield, parametrize IDs | 11 | 0 |
| `tests/test_selenium_checkout.py` | WebDriver, explicit waits, page object | 3 | 0 |
| `tests/test_waits_frames.py` | Waits, iframe, popup, strict mode, console | 6 | 0 |

## Standalone example scripts

- PASS  examples.ch02_money                        0.0s
- PASS  examples.ch02_python_tour                  0.1s
- PASS  examples.ch05_selenium_script              1.5s
- PASS  examples.ch06_playwright_script            1.1s
- PASS  examples.ch07_page_object_script           1.6s
- PASS  examples.ch10_requests_script              0.7s
- PASS  examples.ch11_download_script              1.7s

## Environment

| Component | Version |
|---|---|
| Python | `3.13.17` |
| pytest | `9.1.1` |
| Playwright | `1.63.0` |
| pytest-playwright | `0.10.0` |
| Selenium | `4.51.0` |
| requests | `2.34.2` |
| pypdf | `6.17.0` |
| Browser | `Chrome for Testing 153.0.8010.12` |

## Files in this folder

- `report.html` — full pytest-html report (open in any browser)
- `junit.xml` — machine-readable results (JUnit format, for CI tools)
- `VERIFICATION.md` — this summary

## Reproduce

```bash
python -m pip install -r requirements.txt
python -m playwright install chromium
python -m pytest --html=verification/report.html --self-contained-html
python tools/verify_examples.py
```
